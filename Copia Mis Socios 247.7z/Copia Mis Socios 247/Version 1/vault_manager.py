import os
from google import genai
from google.genai import types

def analizar_archivo(file_path, agente_role):
    api_key = os.environ.get("GOOGLE_API_KEY")
    client = genai.Client(api_key=api_key)
    
    if not file_path or not os.path.exists(file_path):
        return ""
    
    with open(file_path, "rb") as f:
        file_bytes = f.read()
    
    ext = os.path.splitext(file_path)[1].lower()
    mime_type = "image/jpeg"
    if ext == ".pdf": mime_type = "application/pdf"
    elif ext in [".ogg", ".wav", ".mp3"]: mime_type = "audio/ogg"

    try:
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=[
                types.Part.from_bytes(data=file_bytes, mime_type=mime_type),
                f"Analizá esto para {agente_role}. Sé breve y directo."
            ]
        )
        return response.text
    except Exception as e:
        return f"Error: {e}"
