def obtener_checklist():
    return """
    OBJETIVOS PARA FINALIZAR EL ALCANCE:
    1. Definimos si el servicio es Estratégico o Operativo.
    2. Tenemos claro el objetivo del motor para el usuario.
    
    INSTRUCCIÓN: Analiza el historial. Si falta claridad, responde 'FALTAN_DATOS'. Si ya está definido, responde 'OBJETIVOS_CUMPLIDOS'.
    """
