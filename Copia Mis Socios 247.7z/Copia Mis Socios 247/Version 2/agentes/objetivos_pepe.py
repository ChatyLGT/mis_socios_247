def obtener_checklist():
    return """
    Analiza la charla. ¿Tenemos ya el Nombre del negocio, qué hace y cuál es su mayor problema?
    Responde ÚNICAMENTE 'OBJETIVOS_CUMPLIDOS' o 'FALTAN_DATOS'.
    """
