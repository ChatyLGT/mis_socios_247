import os
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

load_dotenv()

def get_connection():
    return psycopg2.connect(os.getenv("DATABASE_URL"))

def crear_usuario(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO usuarios (telegram_id, status_legal) VALUES (%s, FALSE) ON CONFLICT (telegram_id) DO NOTHING", (telegram_id,))
    conn.commit()
    cur.close()
    conn.close()

def obtener_usuario(telegram_id):
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT * FROM usuarios WHERE telegram_id = %s", (telegram_id,))
    res = cur.fetchone()
    cur.close()
    conn.close()
    return res

def actualizar_campo_usuario(telegram_id, campo, valor):
    conn = get_connection()
    cur = conn.cursor()
    query = f"UPDATE usuarios SET {campo} = %s WHERE telegram_id = %s"
    cur.execute(query, (valor, telegram_id))
    conn.commit()
    cur.close()
    conn.close()

def inicializar_adn(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO adn_negocios (usuario_id) SELECT id FROM usuarios WHERE telegram_id = %s ON CONFLICT DO NOTHING", (telegram_id,))
    conn.commit()
    cur.close()
    conn.close()

def actualizar_adn(telegram_id, campo, valor):
    conn = get_connection()
    cur = conn.cursor()
    query = f"UPDATE adn_negocios SET {campo} = %s WHERE usuario_id = (SELECT id FROM usuarios WHERE telegram_id = %s)"
    cur.execute(query, (valor, telegram_id))
    conn.commit()
    cur.close()
    conn.close()

def obtener_contexto_negocio(telegram_id):
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT modelo_negocio FROM adn_negocios an JOIN usuarios u ON an.usuario_id = u.id WHERE u.telegram_id = %s", (telegram_id,))
    res = cur.fetchone()
    cur.close()
    conn.close()
    return res['modelo_negocio'] if res else ""

def borrar_usuario(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    # Purgado en cascada manual para seguridad total
    cur.execute("DELETE FROM adn_negocios WHERE usuario_id = (SELECT id FROM usuarios WHERE telegram_id = %s)", (telegram_id,))
    cur.execute("DELETE FROM usuarios WHERE telegram_id = %s", (telegram_id,))
    conn.commit()
    cur.close()
    conn.close()
