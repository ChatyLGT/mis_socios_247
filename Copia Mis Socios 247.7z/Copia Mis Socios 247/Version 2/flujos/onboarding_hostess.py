import asyncio, os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import db
from core.gemini_multimodal import procesar_multimodal, procesar_texto_puro
from agentes import pepe, maria, hostess, objetivos_pepe, objetivos_maria

def log_bot(agente, respuesta):
    print(f"\033[92m[BOT RESPONSE] 🤖 {agente}: {respuesta}\033[0m")

async def manejar_onboarding(update: Update, context: ContextTypes.DEFAULT_TYPE, telegram_id: int, estado: str, texto_recibido: str):
    user = update.effective_user
    await context.bot.send_chat_action(chat_id=telegram_id, action='typing')

    contexto_previo = db.obtener_contexto_negocio(telegram_id) or ""
    
    # --- FASE 1: SOFÍA (DATOS GENERALES) ---
    if estado == "DATOS_GENERALES":
        prompt = f"{hostess.obtener_prompt()}\n\nMEMORIA ACTUAL: {contexto_previo}"
        respuesta = await procesar_texto_puro(prompt, texto_recibido)
        log_bot("SOFÍA", respuesta)
        
        # Guardamos y verificamos
        nuevo_contexto = f"{contexto_previo}\nUsuario: {texto_recibido}\nSofía: {respuesta}"
        db.actualizar_adn(telegram_id, "modelo_negocio", nuevo_contexto)
        
        check = await procesar_texto_puro("Analiza si tenemos: 1.Nombre Persona, 2.Email, 3.Nombre Negocio. Responde 'LISTO' si están los 3, sino 'FALTA'.", nuevo_contexto)
        
        teclado = [[InlineKeyboardButton("🤝 ¡Datos Listos! Ir con Pepe", callback_data="ir_a_pepe")]] if "LISTO" in check else None
        # Agregamos siempre el botón de Reiniciar para Sofía
        btn_start = [InlineKeyboardButton("🔄 Reiniciar Proceso", callback_data="reiniciar_todo")]
        if teclado: teclado.append(btn_start)
        else: teclado = [btn_start]

        await update.message.reply_text(f"**Sofía:** {respuesta}", reply_markup=InlineKeyboardMarkup(teclado), parse_mode="Markdown")

    # --- FASE 2: PEPE (ADN) ---
    elif estado == "PITCH_NEGOCIO":
        prompt = f"{pepe.obtener_prompt()}\n\nHISTORIAL: {contexto_previo}"
        respuesta = await procesar_texto_puro(prompt, texto_recibido)
        log_bot("PEPE", respuesta)
        
        nuevo_contexto = f"{contexto_previo}\nPitch: {texto_recibido}\nPepe: {respuesta}"
        db.actualizar_adn(telegram_id, "modelo_negocio", nuevo_contexto)
        
        # EL CANDADO: Solo si los objetivos se cumplen
        status = await procesar_texto_puro(objetivos_pepe.obtener_checklist(), nuevo_contexto)
        teclado = [[InlineKeyboardButton("✅ ADN Confirmado - Ir a María", callback_data="confirma_pepe")]] if "OBJETIVOS_CUMPLIDOS" in status else None
        
        await update.message.reply_text(f"**Pepe:** {respuesta}", reply_markup=InlineKeyboardMarkup(teclado) if teclado else None, parse_mode="Markdown")

    # --- FASE 3: MARÍA (ALCANCE) ---
    elif estado == "ALCANCE":
        prompt = f"{maria.obtener_prompt()}\n\nNEGOCIO REAL: {contexto_previo}"
        respuesta = await procesar_texto_puro(prompt, texto_recibido)
        log_bot("MARÍA", respuesta)
        
        nuevo_contexto = f"{contexto_previo}\nAlcance: {texto_recibido}\nMaría: {respuesta}"
        db.actualizar_adn(telegram_id, "tipo_ayuda_esperada", nuevo_contexto)

        status = await procesar_texto_puro(objetivos_maria.obtener_checklist(), nuevo_contexto)
        teclado = [[InlineKeyboardButton("🚀 Finalizar Configuración", callback_data="confirma_maria")]] if "OBJETIVOS_CUMPLIDOS" in status else None
        
        await update.message.reply_text(f"**María:** {respuesta}", reply_markup=InlineKeyboardMarkup(teclado) if teclado else None, parse_mode="Markdown")

async def manejar_botones_flujo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    tid = query.from_user.id
    await query.answer()
    
    if query.data == "reiniciar_todo":
        db.borrar_usuario(tid)
        await query.edit_message_text("♻️ Bóveda reseteada. Iniciá con /start.")
    elif query.data == "ir_a_pepe":
        db.actualizar_campo_usuario(tid, "estado_onboarding", "PITCH_NEGOCIO")
        await query.edit_message_text("**Sistema:** Sofía ha pasado tu reporte a Pepe. 🤝")
    elif query.data == "confirma_pepe":
        db.actualizar_campo_usuario(tid, "estado_onboarding", "ALCANCE")
        await query.edit_message_text("**Sistema:** Pepe ha validado el ADN. María entra en escena. 👩‍💼")
