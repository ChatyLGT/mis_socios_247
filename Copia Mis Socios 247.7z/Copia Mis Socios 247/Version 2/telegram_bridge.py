import os, asyncio
from datetime import datetime
from dotenv import load_dotenv
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

import db
from flujos.onboarding_hostess import manejar_onboarding, log_bot
from core.gemini_multimodal import procesar_texto_puro
from agentes import hostess

load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db_user = db.obtener_usuario(user.id)
    if not db_user:
        db.crear_usuario(user.id)
        db_user = db.obtener_usuario(user.id)

    if not db_user.get('telefono_whatsapp'):
        boton = [[KeyboardButton("📱 Compartir mi WhatsApp", request_contact=True)]]
        await update.message.reply_text("**Sistema:** Bienvenido. Validá tu número para iniciar:", 
                                       reply_markup=ReplyKeyboardMarkup(boton, one_time_keyboard=True, resize_keyboard=True), parse_mode="Markdown")
    elif not db_user.get('status_legal'):
        await enviar_tyc(update.message)
    else:
        await update.message.reply_text("**Sistema:** Tu ecosistema ya está activo. 🚀", parse_mode="Markdown")

async def enviar_tyc(message):
    teclado = [[InlineKeyboardButton("✅ Acepto mi Transformación", callback_data="acepto_tyc")]]
    await message.reply_text("**Sistema:** Aceptá los términos para entrar a la bóveda:", 
                             reply_markup=InlineKeyboardMarkup(teclado), parse_mode="Markdown")

async def boton_inline(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    tid = query.from_user.id
    await query.answer()
    if query.data == "acepto_tyc":
        db.actualizar_campo_usuario(tid, "status_legal", True)
        db.inicializar_adn(tid)
        db.actualizar_campo_usuario(tid, "estado_onboarding", "DATOS_GENERALES")
        await query.edit_message_text("🖋️ Contrato firmado.")
        res = "¡Gracias! Soy **Sofía**, tu musa. Antes de presentarte a los socios, contame: ¿cómo te llamás y cómo se llama tu negocio?"
        log_bot("SOFÍA", res)
        await context.bot.send_message(chat_id=tid, text=res, parse_mode="Markdown")

async def catch_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db_user = db.obtener_usuario(user.id)
    texto = update.message.text or "Hola"
    
    if not db_user or not db_user.get('status_legal'):
        await context.bot.send_chat_action(chat_id=user.id, action='typing')
        respuesta = await procesar_texto_puro(hostess.obtener_prompt(), texto)
        log_bot("SOFÍA", respuesta)
        # Sofía siempre ofrece el botón de inicio si no han empezado
        teclado = [[InlineKeyboardButton("🚀 Iniciar Proceso /start", callback_data="reiniciar_todo")]]
        await update.message.reply_text(f"**Sofía:** {respuesta}", reply_markup=InlineKeyboardMarkup(teclado), parse_mode="Markdown")
        return

    print(f"[{datetime.now().strftime('%H:%M:%S')}] 🟢 INPUT RECIBIDO | {user.first_name}: {texto}")
    await manejar_onboarding(update, context, user.id, db_user['estado_onboarding'], texto)

if __name__ == '__main__':
    print("🚀 [SISTEMA BLINDADO - NEGATIVO A BOTONES PREMATUROS] Esperando...")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(boton_inline, pattern="^acepto_tyc$"))
    from flujos.onboarding_hostess import manejar_botones_flujo
    app.add_handler(CallbackQueryHandler(manejar_botones_flujo, pattern="^(confirma_|ir_a_pepe|reiniciar_todo)"))
    app.add_handler(MessageHandler(filters.CONTACT, lambda u, c: db.actualizar_campo_usuario(u.effective_user.id, "telefono_whatsapp", u.message.contact.phone_number) or start(u, c)))
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, catch_all))
    app.run_polling()
