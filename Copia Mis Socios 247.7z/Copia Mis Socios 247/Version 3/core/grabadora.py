from datetime import datetime

AZUL, VERDE, AMARILLO, ROJO, CYAN, RESET = "\033[94m", "\033[92m", "\033[93m", "\033[91m", "\033[96m", "\033[0m"

def log_terminal(tipo, usuario, detalle):
    hora = datetime.now().strftime("%H:%M:%S")
    color_user = ROJO if usuario == "DESCONOCIDO" else CYAN
    if "COMANDO" in tipo or "CALLBACK" in tipo: color_tipo = AMARILLO
    elif "TEXTO" in tipo: color_tipo = AZUL
    elif "SISTEMA" in tipo: color_tipo = ROJO
    else: color_tipo = CYAN
    
    print(f"{color_tipo}[{hora}] 📥 {tipo} | User: {color_user}{usuario}{color_tipo} | {detalle}{RESET}")

def log_bot_response(agente, respuesta):
    hora = datetime.now().strftime("%H:%M:%S")
    # GRABACIÓN TOTAL: No se corta NADA.
    print(f"\n{VERDE}[{hora}] 🤖 RESPONSE | Agente: {agente} | {respuesta}{RESET}\n")
