from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

def obtener_teclado_por_estado(estado):
    if estado == "NUEVO":
        # Botón para forzar el inicio del flujo
        return InlineKeyboardMarkup([[InlineKeyboardButton("🚀 Iniciar Registro /start", callback_data="start_flow")]])
    
    if estado == "WHATSAPP":
        return ReplyKeyboardMarkup([[KeyboardButton("📱 Compartir mi WhatsApp", request_contact=True)]], 
                                   resize_keyboard=True, one_time_keyboard=True)
    
    if estado == "TYC":
        return InlineKeyboardMarkup([[InlineKeyboardButton("✅ Acepto los Términos", callback_data="acepto_tyc")]])
    
    if estado == "PASO_PEPE":
        return InlineKeyboardMarkup([[InlineKeyboardButton("🤝 Ir con Pepe", callback_data="ir_a_pepe")]])
        
    return None
