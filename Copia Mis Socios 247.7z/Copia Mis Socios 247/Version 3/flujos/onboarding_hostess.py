import db
from core.gemini_multimodal import procesar_texto_puro, procesar_multimodal
from core.grabadora import log_bot_response
from agentes import hostess
from core.ui import obtener_teclado_por_estado

async def manejar_onboarding(update, context, telegram_id, estado, texto, file_path=None):
    contexto_previo = db.obtener_contexto_negocio(telegram_id) or ""
    
    # 1. Sofía genera su respuesta
    prompt = f"{hostess.obtener_prompt()}\nESTADO ACTUAL: {estado}\nHISTORIAL: {contexto_previo}"
    res = await (procesar_multimodal(file_path, prompt) if file_path else procesar_texto_puro(prompt, texto))
    
    # 2. Registrar la respuesta completa en tu grabadora
    log_bot_response("SOFÍA", res)
    
    # 3. Emisor Universal: Detectar si es mensaje o callback (botón)
    target = update.message if update.message else update.callback_query.message
    
    # 4. Adjuntar el botón correspondiente al estado
    teclado = obtener_teclado_por_estado(estado)

    # 5. Enviar respuesta sin que explote el 'NoneType'
    await target.reply_text(f"**Sofía:** {res}", reply_markup=teclado, parse_mode="Markdown")
