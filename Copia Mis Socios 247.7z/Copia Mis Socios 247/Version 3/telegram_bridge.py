import os, db, asyncio
from dotenv import load_dotenv
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters
import db
from core.borrado import ejecutar_borrado_total
from core.registro import manejar_paso_registro
from core.grabadora import log_terminal, log_bot_response
from flujos.onboarding_hostess import manejar_onboarding

load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")

async def catch_all(update, context):
    user = update.effective_user
    msg = update.message
    if not user or not msg: return

    db_user = db.obtener_usuario(user.id)
    nombre_log = user.first_name if db_user else "DESCONOCIDO"
    file_path = None # Por ahora simplificado para evitar TypeErrors
    
    texto = msg.text or "Acción Multimedia"
    log_terminal("TEXTO", nombre_log, texto)

    if not db_user:
        await manejar_onboarding(update, context, user.id, "NUEVO", texto, file_path)
    elif not db_user.get('telefono_whatsapp'):
        await manejar_onboarding(update, context, user.id, "WHATSAPP", texto, file_path)
    elif not db_user.get('status_legal'):
        await manejar_onboarding(update, context, user.id, "TYC", texto, file_path)
    else:
        estado = db_user.get('estado_onboarding', 'DATOS_GENERALES')
        await manejar_onboarding(update, context, user.id, estado, texto, file_path)

async def manejar_callback(update, context):
    query = update.callback_query
    user = update.effective_user
    db_user = db.obtener_usuario(user.id)
    nombre_log = user.first_name if db_user else "DESCONOCIDO"
    
    log_terminal("CALLBACK", nombre_log, f"Clic en: {query.data}")
    await query.answer()

    if query.data == "acepto_tyc":
        db.actualizar_campo_usuario(user.id, "status_legal", True)
        db.inicializar_adn(user.id)
        db.actualizar_campo_usuario(user.id, "estado_onboarding", "DATOS_GENERALES")
        log_terminal("SISTEMA", nombre_log, "Contrato Firmado ✅")
        await query.edit_message_text("🖋️ Contrato firmado con éxito.")
        # Llamamos a Sofía con los 6 argumentos necesarios
        await manejar_onboarding(update, context, user.id, "DATOS_GENERALES", "Contrato firmado", None)
    elif query.data == "start_flow":
        await manejar_paso_registro(update, context)

if __name__ == '__main__':
    print("🚀 [SISTEMA DE TITANIO] - Omnisciencia Total Activada")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("eraseall", ejecutar_borrado_total))
    app.add_handler(CommandHandler("start", manejar_paso_registro))
    app.add_handler(CallbackQueryHandler(manejar_callback))
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, catch_all))
    app.run_polling()
